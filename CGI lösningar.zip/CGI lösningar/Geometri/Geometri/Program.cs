﻿///
/// Beräkna arean o omkretsen på en kvadrat, rektangel och parallelltrapets
/// Skriv ut arean, omkretsen och vilken typ av figur det är, skriv ut i consolen
/// Jag har skapat 3 arrayer, arrayen avgör vilken typ figur det är
/// Var kreativ och visa att du testat din lösning noga

using System;

namespace Geometri
{
    public abstract class Shape
    {
        protected double area;
        protected int circumference;
        protected string shapeinfo;

        protected abstract void areaOf(int[] shape);
        protected abstract void circumferenceOf(int[] shape);
        public abstract void shapeInfo();

    }

    public class Square : Shape
    {   

        public Square(int[] square)
        {
            if (square[0].Equals(square[1])) { 
            areaOf(square);
            circumferenceOf(square);
            shapeinfo += "Detta är en kvadrat" + System.Environment.NewLine + "Omkretsen är: " + area.ToString() + System.Environment.NewLine + "Arean är: " + circumference.ToString() + System.Environment.NewLine;
            }
            else
            {
                throw new InvalidOperationException("no valid input");
            }
            
        }
        protected override void areaOf(int[] shape)
        {
            area = (shape[0] * 4);
        }

        protected override void circumferenceOf(int[] shape)
        {
            circumference = (shape[0] * shape[0]);
        }

        public override void shapeInfo()
        {
            Console.WriteLine(shapeinfo);
        }
    }
    public class Rectangle : Shape
    {
        public Rectangle(int[] rect)
        {   if(rect[0].Equals(rect[2]) && rect[1].Equals(rect[3])) { 
            areaOf(rect);
            circumferenceOf(rect);
            shapeinfo = "Detta är en rektangel" + System.Environment.NewLine + "Omkretsen är: " + area.ToString() + System.Environment.NewLine + "Arean är: " + circumference.ToString() + System.Environment.NewLine;
            }
            else
            {
               throw new InvalidOperationException("no valid input");
            }
            
        }
        protected override void areaOf(int[] shape)
        {
            area = (shape[0] * shape[1]);
        }

        protected override void circumferenceOf(int[] shape)
        {
            circumference = (shape[0] * 2 + shape[1] * 2);
        }

        public override void shapeInfo()
        {
            Console.WriteLine(shapeinfo);
        }
    }

    public class Trapezoid : Shape
    {
        public Trapezoid(int[] trap) {
            areaOf(trap);
            circumferenceOf(trap);
            shapeinfo = "Detta är en parallelltrapets" + System.Environment.NewLine + "Omkretsen är: " + area.ToString() + System.Environment.NewLine + "Arean är: " + circumference.ToString() + System.Environment.NewLine;
        }
        protected override void areaOf(int[] shape)
        {
            area = ((shape[0] + shape[2]) / 2 * shape[4]);
        }

        protected override void circumferenceOf(int[] shape)
        {
            for (int i = 0; i < 3; i++) { circumference += shape[i]; };
        }

        public override void shapeInfo()
        {
            Console.WriteLine(shapeinfo);
        }
    }

    public class ShapeChooser
    {
        public ShapeChooser() { }
        public Shape getShape(int[] shape)
        {

            if (shape.Length.Equals(2))
            {
                 Square square = new Square(shape);
                return square;

            }
            else if (shape.Length.Equals(4))
            {
                Rectangle rect = new Rectangle(shape);
                return rect;
            }
            else if (shape.Length.Equals(5))
            {
                Trapezoid trap = new Trapezoid(shape);
                return trap;

            }
            throw new InvalidOperationException("No such Shape implemented");
        }
        }

        class Program
    {
        static void Main(string[] args)
        {
            int[] figur1 = new int[] { 5, 5 };
            int[] figur2 = new int[] { 5, 4, 5, 4 };
            int[] figur3 = new int[] { 5, 5, 4, 4, 3 };
            ShapeChooser shaper = new ShapeChooser();
            shaper.getShape(figur1).shapeInfo();
            shaper.getShape(figur2).shapeInfo();
            shaper.getShape(figur3).shapeInfo();

            int[] figur5 = new int[] { 6, 3 };
            //shaper.getShape(figur5).shapeInfo();
            int[] figur6 = new int[] { 6, 3, 6 ,1 };
            int[] figur7 = new int[] { 6, 3, 2, 1 };
            int[] figur8 = new int[] { 6, 3, 2, 3 };
            //shaper.getShape(figur6).shapeInfo();
            //shaper.getShape(figur7).shapeInfo();
            //shaper.getShape(figur8).shapeInfo();
            int[] figur4 = new int[] { 5, 5, 5, 5, 5, 5, 5, 5 };
            shaper.getShape(figur4).shapeInfo();

            Console.ReadLine();
        }
    }
}