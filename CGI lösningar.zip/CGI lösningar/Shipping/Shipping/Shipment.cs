﻿using System;
using System.Linq;
using System.Collections.Generic;


namespace Shipping {
public class Shipment
{
        double cost;
        string land;
        string person;
        string[] checkdiscount;
        double discount = 1;
        double result;
        string filepath;
        string temp;
    public Shipment(Order order)
    {           
            foreach (var pair in order.LineItems)
            {
                
              double itemcost = pair.Key.Pris* pair.Value;
                cost += itemcost;
            }

            land = order.Mottagare.Land;
            person = order.Mottagare.Namn;
            filepath = @"C:\Users\edvin\Documents\Jobb\CGI\Shipping\Shipping\Discount.txt";
            checkdiscount = System.IO.File.ReadAllLines(filepath);

            System.Collections.IEnumerator enumerator = checkdiscount.GetEnumerator();
            while(enumerator.MoveNext() && enumerator.Current != null) { 
                
                if (enumerator.Current.Equals(land)){
                    enumerator.MoveNext();
                    if (Double.TryParse((string)enumerator.Current, out result))
                    {
                        discount = result;
                    }
                    
                    break;
                }
                
            }
            cost += (order.Mottagare.FraktKostnad * discount);
            

    }
        public void printShipment()
        {
            System.Console.WriteLine(land + System.Environment.NewLine + person + System.Environment.NewLine + cost + System.Environment.NewLine);
        }
}
}