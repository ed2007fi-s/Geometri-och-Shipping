﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shipping
{
    public class Order
    {
        public Dictionary<Item, int> LineItems { get; } = new Dictionary<Item, int>();


        public Address Mottagare { get; set; }


    }

    public class Address
    {
        public string Namn { get; set; }
        public string Land { get; set; }

        public int FraktKostnad { get; set; }
    }
}
